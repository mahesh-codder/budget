"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { PlusCircle, Trash2, Edit3, DollarSign, TrendingUp, TrendingDown, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface Transaction {
  id: string
  type: "income" | "expense"
  amount: number
  category: string
  date: string
  notes: string
}

interface Budget {
  monthly: number
}

const categories = {
  income: ["Salary", "Freelance", "Investment", "Gift", "Other Income"],
  expense: ["Food", "Transportation", "Entertainment", "Bills", "Shopping", "Healthcare", "Other Expense"],
}

export default function FinanceTracker() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [budget, setBudget] = useState<Budget>({ monthly: 0 })
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null)
  const [filterCategory, setFilterCategory] = useState<string>("all")
  const [filterMonth, setFilterMonth] = useState<string>("all")

  // Form state
  const [formData, setFormData] = useState({
    type: "expense" as "income" | "expense",
    amount: "",
    category: "",
    date: new Date().toISOString().split("T")[0],
    notes: "",
  })

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedTransactions = localStorage.getItem("finance-transactions")
    const savedBudget = localStorage.getItem("finance-budget")

    if (savedTransactions) {
      setTransactions(JSON.parse(savedTransactions))
    }

    if (savedBudget) {
      setBudget(JSON.parse(savedBudget))
    }
  }, [])

  // Save to localStorage whenever transactions or budget change
  useEffect(() => {
    localStorage.setItem("finance-transactions", JSON.stringify(transactions))
  }, [transactions])

  useEffect(() => {
    localStorage.setItem("finance-budget", JSON.stringify(budget))
  }, [budget])

  // Calculate totals
  const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

  const totalExpense = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

  const currentBalance = totalIncome - totalExpense

  // Calculate current month expenses for budget tracking
  const currentMonth = new Date().toISOString().slice(0, 7)
  const currentMonthExpenses = transactions
    .filter((t) => t.type === "expense" && t.date.startsWith(currentMonth))
    .reduce((sum, t) => sum + t.amount, 0)

  const budgetUsagePercentage = budget.monthly > 0 ? (currentMonthExpenses / budget.monthly) * 100 : 0

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.amount || !formData.category) {
      alert("Please fill in all required fields")
      return
    }

    const transaction: Transaction = {
      id: editingTransaction?.id || Date.now().toString(),
      type: formData.type,
      amount: Number.parseFloat(formData.amount),
      category: formData.category,
      date: formData.date,
      notes: formData.notes,
    }

    if (editingTransaction) {
      setTransactions((prev) => prev.map((t) => (t.id === editingTransaction.id ? transaction : t)))
      setEditingTransaction(null)
    } else {
      setTransactions((prev) => [...prev, transaction])
    }

    // Reset form
    setFormData({
      type: "expense",
      amount: "",
      category: "",
      date: new Date().toISOString().split("T")[0],
      notes: "",
    })
  }

  // Handle edit transaction
  const handleEdit = (transaction: Transaction) => {
    setEditingTransaction(transaction)
    setFormData({
      type: transaction.type,
      amount: transaction.amount.toString(),
      category: transaction.category,
      date: transaction.date,
      notes: transaction.notes,
    })
  }

  // Handle delete transaction
  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this transaction?")) {
      setTransactions((prev) => prev.filter((t) => t.id !== id))
    }
  }

  // Filter transactions
  const filteredTransactions = transactions.filter((transaction) => {
    const categoryMatch = filterCategory === "all" || transaction.category === filterCategory
    const monthMatch = filterMonth === "all" || transaction.date.startsWith(filterMonth)
    return categoryMatch && monthMatch
  })

  // Get unique months from transactions
  const uniqueMonths = [...new Set(transactions.map((t) => t.date.slice(0, 7)))].sort().reverse()

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Personal Finance Tracker</h1>
          <p className="text-gray-600">Track your income, expenses, and budget all in one place</p>
        </div>

        {/* Dashboard Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Income</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">${totalIncome.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
              <TrendingDown className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">${totalExpense.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
              <Wallet className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${currentBalance >= 0 ? "text-green-600" : "text-red-600"}`}>
                ${currentBalance.toFixed(2)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Budget Usage</CardTitle>
              <DollarSign className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{budgetUsagePercentage.toFixed(1)}%</div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div
                  className={`h-2 rounded-full ${budgetUsagePercentage > 100 ? "bg-red-500" : budgetUsagePercentage > 80 ? "bg-yellow-500" : "bg-green-500"}`}
                  style={{ width: `${Math.min(budgetUsagePercentage, 100)}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                ${currentMonthExpenses.toFixed(2)} of ${budget.monthly.toFixed(2)}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Transaction Form */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PlusCircle className="h-5 w-5" />
                {editingTransaction ? "Edit Transaction" : "Add Transaction"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: "income" | "expense") =>
                      setFormData((prev) => ({ ...prev, type: value, category: "" }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="expense">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="amount">Amount</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.amount}
                    onChange={(e) => setFormData((prev) => ({ ...prev, amount: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories[formData.type].map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData((prev) => ({ ...prev, date: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    placeholder="Optional notes..."
                    value={formData.notes}
                    onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                  />
                </div>

                <div className="flex gap-2">
                  <Button type="submit" className="flex-1">
                    {editingTransaction ? "Update" : "Add"} Transaction
                  </Button>
                  {editingTransaction && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setEditingTransaction(null)
                        setFormData({
                          type: "expense",
                          amount: "",
                          category: "",
                          date: new Date().toISOString().split("T")[0],
                          notes: "",
                        })
                      }}
                    >
                      Cancel
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Budget Setting & Transaction History */}
          <div className="lg:col-span-2 space-y-6">
            {/* Budget Setting */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Budget</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 items-end">
                  <div className="flex-1">
                    <Label htmlFor="budget">Monthly Budget Amount</Label>
                    <Input
                      id="budget"
                      type="number"
                      step="0.01"
                      placeholder="Enter monthly budget"
                      value={budget.monthly || ""}
                      onChange={(e) => setBudget({ monthly: Number.parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>Current month expenses: ${currentMonthExpenses.toFixed(2)}</p>
                    <p>Remaining: ${(budget.monthly - currentMonthExpenses).toFixed(2)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <div className="flex-1">
                    <Label htmlFor="filter-category">Filter by Category</Label>
                    <Select value={filterCategory} onValueChange={setFilterCategory}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {[...categories.income, ...categories.expense].map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="filter-month">Filter by Month</Label>
                    <Select value={filterMonth} onValueChange={setFilterMonth}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Months</SelectItem>
                        {uniqueMonths.map((month) => (
                          <SelectItem key={month} value={month}>
                            {new Date(month + "-01").toLocaleDateString("en-US", { year: "numeric", month: "long" })}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Transaction Table */}
                <div className="overflow-x-auto">
                  {filteredTransactions.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>No transactions found</p>
                      <p className="text-sm">Add your first transaction to get started!</p>
                    </div>
                  ) : (
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Date</th>
                          <th className="text-left p-2">Category</th>
                          <th className="text-left p-2">Amount</th>
                          <th className="text-left p-2">Type</th>
                          <th className="text-left p-2">Notes</th>
                          <th className="text-left p-2">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredTransactions
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .map((transaction) => (
                            <tr key={transaction.id} className="border-b hover:bg-gray-50">
                              <td className="p-2">{new Date(transaction.date).toLocaleDateString()}</td>
                              <td className="p-2">{transaction.category}</td>
                              <td
                                className={`p-2 font-semibold ${transaction.type === "income" ? "text-green-600" : "text-red-600"}`}
                              >
                                {transaction.type === "income" ? "+" : "-"}${transaction.amount.toFixed(2)}
                              </td>
                              <td className="p-2">
                                <span
                                  className={`px-2 py-1 rounded-full text-xs ${transaction.type === "income" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                                >
                                  {transaction.type}
                                </span>
                              </td>
                              <td className="p-2 max-w-xs truncate">{transaction.notes}</td>
                              <td className="p-2">
                                <div className="flex gap-2">
                                  <Button size="sm" variant="outline" onClick={() => handleEdit(transaction)}>
                                    <Edit3 className="h-4 w-4" />
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => handleDelete(transaction.id)}>
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
